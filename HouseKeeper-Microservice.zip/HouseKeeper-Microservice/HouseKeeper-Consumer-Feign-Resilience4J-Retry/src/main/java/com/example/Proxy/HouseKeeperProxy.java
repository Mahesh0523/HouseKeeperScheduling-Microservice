package com.example.Proxy;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.Entity.Worker;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;


@FeignClient(name="housekeeper-service")
public interface HouseKeeperProxy {

	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod = "fallbackgetWorkerByFloor")
	@GetMapping("/getHouseKeeperByFloor/{floor}/{hostel}")
	public List<Worker> getWorkerByFloor(@PathVariable("floor") int floor,@PathVariable("hostel") String hostel);
	
	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod = "fallbackgetWorkerByHostel")
	@GetMapping("/getHouseKeeperByHostel/{hostel}")
	public List<Worker> getWorkerByHostel(@PathVariable("hostel") String hostel);
	
	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod = "fallbackgetAllWorkers")
	@GetMapping("/getAllWorkers")
	public List<Worker> getAllWorkers();
	
	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod = "fallbackgetWorkerById")
	@GetMapping("getWorkers/{workerId}")
	public Worker getWorkerById(@PathVariable("workerId") int workerId);
	
	public default List<Worker> fallbackgetWorkerByFloor(int floor, String hostel, Throwable cause) {
		// TODO Auto-generated method stub
		System.out.println("Exception occured with message"+ cause.getMessage());

		return new ArrayList<Worker>();
	}
	
	
	public default List<Worker> fallbackgetWorkerByHostel(String hostel, Throwable cause) {
		System.out.println("Exception occured with message"+ cause.getMessage());

		return new ArrayList<Worker>();
	}

	public default List<Worker> fallbackgetAllWorkers( Throwable cause) {
		System.out.println("Exception occured with message"+ cause.getMessage());

		return new ArrayList<Worker>();
	}

	
	public default Worker fallbackgetWorkerById(int workerId,  Throwable cause) {
		System.out.println("Exception occured with message"+ cause.getMessage());

		return new Worker(1, "XYZ", 3, "Welcome",null);
	}

}
