package com.example.Entity;

import java.sql.Date;
import java.time.LocalTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CleanRequest {

	
	

	private int request_id;

	public CleanRequest(int request_id, Date date, LocalTime cleanTime, boolean feedback_status, Student student,
			Worker worker, boolean req_status) {
		super();
		this.request_id = request_id;
		this.date = date;
		this.cleanTime = cleanTime;
		this.feedback_status = feedback_status;
		this.student = student;
		this.worker = worker;
		this.req_status = req_status;
	}

	private Date date;
	
	private LocalTime cleanTime;
	
	private boolean feedback_status;
	
	
	private Student student;
	
	
	private Worker worker;
	
	
	private boolean req_status;

	
	public boolean isFeedback_status() {
		return feedback_status;
	}

	public void setFeedback_status(boolean feedback_status) {
		this.feedback_status = feedback_status;
	}

	public int getRequest_id() {
		return request_id;
	}

	public void setRequest_id(int request_id) {
		this.request_id = request_id;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}


	public Worker getWorker() {
		return worker;
	}

	public void setWorker(Worker worker) {
		this.worker = worker;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public LocalTime getCleanTime() {
		return cleanTime;
	}

	public void setCleanTime(LocalTime cleanTime) {
		this.cleanTime = cleanTime;
	}

	public boolean isReq_status() {
		return req_status;
	}

	public void setReq_status(boolean req_status) {
		this.req_status = req_status;
	}
	
	@Override
	public String toString() {
		return "CleanRequest [request_id=" + request_id + ", date=" + date + ", cleanTime=" + cleanTime
				+ ", feedback_status=" + feedback_status + ", student=" + student + ", worker=" + worker
				+ ", req_status=" + req_status + "]";
	}
	
	
}
