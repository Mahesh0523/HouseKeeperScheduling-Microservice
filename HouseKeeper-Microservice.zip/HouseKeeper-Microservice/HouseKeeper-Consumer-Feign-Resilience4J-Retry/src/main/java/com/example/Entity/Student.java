package com.example.Entity;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Student {

	
	private long rollnumber;
	public Student(long rollnumber, String password, int floor, String hostel, String room, List<Feedback> feedbacks,
			List<CleanRequest> request_id) {
		super();
		this.rollnumber = rollnumber;
		this.password = password;
		this.floor = floor;
		this.hostel = hostel;
		this.room = room;
		this.feedbacks = feedbacks;
		this.request_id = request_id;
	}

	private String password;
	private int floor;
	private String hostel;
	private String room;
	
	private List<Feedback> feedbacks;
	
	//mappedBy = "student",
	
	private List<CleanRequest> request_id;
	
	
	
	
	public Student() {
		// TODO Auto-generated constructor stub
	}
	
	
	public void setFeedbacks(List<Feedback> feedbacks) {
		this.feedbacks = feedbacks;
	}
	
	public void setRequest_id(List<CleanRequest> request_id) {
		this.request_id = request_id;
	}
	public String getRoom() {
		return room;
	}
	public void setRoom(String room) {
		this.room = room;
	}
	
	public long getRollnumber() {
		return rollnumber;
	}
	public void setRollnumber(long rollnumber) {
		this.rollnumber = rollnumber;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getFloor() {
		return floor;
	}
	public void setFloor(int floor) {
		this.floor = floor;
	}
	public String getHostel() {
		return hostel;
	}
	public void setHostel(String hostel) {
		this.hostel = hostel;
	}

	@Override
	public String toString() {
		return "Student [rollnumber=" + rollnumber + ", password=" + password + ", floor=" + floor + ", hostel="
				+ hostel + ", room=" + room + ", feedbacks=" + feedbacks + ", request_id=" + request_id + "]";
	}
	
	
	

}
