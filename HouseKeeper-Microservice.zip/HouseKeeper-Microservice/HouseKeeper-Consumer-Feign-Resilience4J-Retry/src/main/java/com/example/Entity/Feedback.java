package com.example.Entity;



import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Feedback {

	
	
	public Feedback(long feedback_id, Student student, CleanRequest cleanRequest, String feedback) {
		super();
		this.feedback_id = feedback_id;
		this.student = student;
		this.cleanRequest = cleanRequest;
		this.feedback = feedback;
	}

	private long feedback_id;
	
	
	private Student student;
	
	
	private CleanRequest cleanRequest;
	
	
	private String feedback;
	
	
	public long getFeedback_id() {
		return feedback_id;
	}
	public void setFeedback_id(long feedback_id) {
		this.feedback_id = feedback_id;
	}
	
	
	
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public CleanRequest getCleanRequest() {
		return cleanRequest;
	}
	public void setCleanRequest(CleanRequest cleanRequest) {
		this.cleanRequest = cleanRequest;
	}
	public String getFeedback() {
		return feedback;
	}
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	
	@Override
	public String toString() {
		return "Feedback [feedback_id=" + feedback_id + ", student=" + student + ", cleanRequest=" + cleanRequest
				+ ", feedback=" + feedback + "]";
	}
	
	
}
