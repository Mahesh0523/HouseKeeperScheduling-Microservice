package com.example.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import com.example.Entity.CleanRequest;
import com.example.Entity.Student;
import com.example.Entity.Worker;
import com.example.Proxy.AdminProxy;
import com.example.Proxy.RequestProxy;
import com.example.Proxy.StudentProxy;
//import com.example.Service.CleanRequestService;
//import com.example.Service.StudentService;
//import com.example.Service.WorkerService;
//
@RestController
@CrossOrigin("*")
public class CleanRequestController {
//
////	@Autowired
////	private CleanRequestService cleanRequestService;
////	
////	@Autowired
////	private StudentService studentService;
////	
////	@Autowired
////	private WorkerService workerService;
//	
	@Autowired
	private RequestProxy requestproxy;
	
	@Autowired
	private StudentProxy studentproxy;
	

	@GetMapping("/requestCount/{rollno}")
	public List<Integer> getRequestCount(@PathVariable("rollno") long rollno){
		return this.requestproxy.getRequestCount(rollno);
	}
	
	@GetMapping("/getCleanRequestByRollnumber/{rollno}")
	public List<CleanRequest> getCleanRequestByRollnumber(@PathVariable("rollno") long rollno){
		Student student = this.studentproxy.getStudent(rollno);
		return this.requestproxy.getCleanRequestByRollnumber(rollno);
	}
	
	@GetMapping("/getRequestById/{id}")
	public CleanRequest getCleanRequestById(@PathVariable("id") int id) {
		return this.requestproxy.getCleanRequestById(id);
	}
	
	@GetMapping("/getAllCleanRequestByHostel/{hostel}")
	public List<CleanRequest> getAllCleanRequest(@PathVariable("hostel") String hostel){
	   return this.requestproxy.getAllCleanRequest(hostel);
	}
	
	@GetMapping("/getAllCleanRequestCountByHostel/{hostel}")
	public Integer getAllCleanRequestCount(@PathVariable("hostel") String hostel) {
		return this.requestproxy.getAllCleanRequestCount(hostel);
	}
	

//
//	
//	@GetMapping("/allotHouseKeeper/{cleanRequestId}/{workerId}")
//	public CleanRequest allotHouseKeeper(@PathVariable("cleanRequestId") int cleanRequestId,@PathVariable("workerId") int workerId) {
//		
//		CleanRequest cleanRequestById = this.housekeeperproxy.getCleanRequestById(cleanRequestId);
//		Worker workerById = this.housekeeperproxy.getWorkerById(workerId);
//		cleanRequestById.setWorker(workerById);
//		cleanRequestById.setReq_status(true);
//		return this.housekeeperproxy.submitRequest(cleanRequestById);
//		
//	}
	
////@PostMapping("/submitRequest/{rollno}")
////public CleanRequest submitRequest(@PathVariable("rollno") long rollno,@RequestBody CleanRequest cleanRequest) {
////	
////	 Student student = this.studentService.getStudent(rollno);
////	 cleanRequest.setStudent(student);
////	 
////	 CleanRequest submitRequest = this.cleanRequestService.submitRequest(cleanRequest);
////
////	 return submitRequest;
////
////}
//
}
