package com.example.Proxy;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.Entity.Admin;
import com.example.Entity.CleanRequest;
import com.example.Entity.Student;
import com.example.Entity.Worker;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name="housekeeper-service")
public interface AdminProxy {
 
	@Retry(name="getAdmin-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod = "FallbackMethodforgetAdmin")
	@GetMapping("/getAdmin")
	public List<Admin> getAdmin();

	@Retry(name="getAdminById-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod = "FallbackMethodforgetAdminById")
	@GetMapping("/getAdminById/{adminId}")
	public Admin getAdminById(@PathVariable("adminId") int id);
	
	
	public default List<Admin> FallbackMethodforgetAdmin(Throwable cause) {
		System.out.println("Exception occured with message"+ cause.getMessage());
		return new ArrayList<Admin>();
	}

	
	public default Admin FallbackMethodforgetAdminById(int id, Throwable cause) {
		System.out.println("Exception occured with message"+ cause.getMessage());
		return new Admin(1, "Abraham", "Abraham123", "Visit");
	}
	
}
