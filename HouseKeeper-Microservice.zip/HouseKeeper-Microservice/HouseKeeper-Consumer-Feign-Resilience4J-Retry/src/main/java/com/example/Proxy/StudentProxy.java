package com.example.Proxy;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.Entity.Student;


import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name="housekeeper-service")
public interface StudentProxy {

	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod = "fallbackgetStudent")
	@GetMapping("/getStudent/{rollno}")
	public Student getStudent(@PathVariable("rollno") long rollnumber);

	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod = "fallbackgetAllStudent")
	@GetMapping("/getAllStudent")
	public List<Student> getAllStudent();
	
	
	
	public default Student fallbackgetStudent(long rollnumber, Throwable cause) {
		// TODO Auto-generated method stub
		System.out.println("Exception occured with message"+ cause.getMessage());

		return new Student(101, "AABB", 12, "VISIT", "12", null, null);
	}

	
	public default List<Student> fallbackgetAllStudent(Throwable cause) {
		// TODO Auto-generated method stub
		System.out.println("Exception occured with message"+ cause.getMessage());

		return new ArrayList<Student>();
	}

}
