package com.example.Entity;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class Worker {

	
	
	public Worker(int worker_id, String name, int floor, String hostel, List<CleanRequest> cleanRequest) {
		super();
		this.worker_id = worker_id;
		this.name = name;
		this.floor = floor;
		this.hostel = hostel;
		this.cleanRequest = cleanRequest;
	}

	private int worker_id;
	private String name;
	private int floor;
	private String hostel;
	

	private List<CleanRequest> cleanRequest;
	
	public String getHostel() {
		return hostel;
	}
	public void setHostel(String hostel) {
		this.hostel = hostel;
	}
	public void setWorker_id(int worker_id) {
		this.worker_id = worker_id;
	}
	
	public void setCleanRequest(List<CleanRequest> cleanRequest) {
		this.cleanRequest = cleanRequest;
	}
	public int getWorker_id() {
		return worker_id;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getFloor() {
		return floor;
	}
	public void setFloor(int floor) {
		this.floor = floor;
	}
	
	@Override
	public String toString() {
		return "Worker [worker_id=" + worker_id + ", name=" + name + ", floor=" + floor + ", hostel=" + hostel
				+ ", cleanRequest=" + cleanRequest + "]";
	}
	
	
}
