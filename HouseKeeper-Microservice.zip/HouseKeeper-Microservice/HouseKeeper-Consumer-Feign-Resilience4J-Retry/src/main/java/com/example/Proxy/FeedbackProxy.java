package com.example.Proxy;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.Entity.Feedback;
import com.example.Entity.Student;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;


@FeignClient(name="housekeeper-service")
public interface FeedbackProxy {

	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod = "FallBackgetAllFeedbackByHostel")
	@GetMapping("/getAllFeedbackByHostel/{hostel}")
	public List<Feedback> getAllFeedbackByHostel(@PathVariable("hostel") String hostel);

	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod = "FallBackgetFeedbackCount")
	@GetMapping("/getFeedbackCount/{hostel}")
	public Integer getFeedbackCount(@PathVariable("hostel") String hostel);

	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod = "FallBackgetFeedbackCountByRollnumber")
	@GetMapping("/getFeedbackCountByRollnumber/{rollnumber}")
	public Integer getFeedbackCountByRollnumber(@PathVariable("rollnumber") long rollnumber);
	
	
	public default List<Feedback> FallBackgetAllFeedbackByHostel(String hostel, Throwable cause) {
		// TODO Auto-generated method stub
		System.out.println("Exception occured with message"+ cause.getMessage());

		return new ArrayList<Feedback>();
	}

	
	public default Integer FallBackgetFeedbackCount(String hostel, Throwable cause) {
		// TODO Auto-generated method stub
		System.out.println("Exception occured with message"+ cause.getMessage());

		return 0;
	}

	
	public default Integer FallBackgetFeedbackCountByRollnumber(long rollnumber, Throwable cause) {
		System.out.println("Exception occured with message"+ cause.getMessage());

		return 0;
	}

}
