package com.example.Controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Entity.CleanRequest;
import com.example.Entity.Feedback;
import com.example.Entity.Student;
import com.example.Proxy.FeedbackProxy;
import com.example.Proxy.StudentProxy;

//
@RestController
@CrossOrigin("*")
public class FeedbackController {
//
//	@Autowired
//	private FeedbackService feedbackService;
//	
//	@Autowired
//	private CleanRequestService cleanRequestService;
//	
	@Autowired
	private FeedbackProxy feedbackproxy;
	
	@Autowired
	private StudentProxy studentproxy;
	
	private static final Logger Log = LoggerFactory.getLogger(AdminController.class);


  	@GetMapping("/getAllFeedbackByHostel/{hostel}")
	public List<Feedback> getAllFeedbackByHostel(@PathVariable("hostel") String hostel){
  		Log.debug("In the getAllFeedbackByHostel method");
  		List<Feedback> feedback= feedbackproxy.getAllFeedbackByHostel(hostel);
  		Log.debug("returned value"+feedback);
  		return feedback;
	}
  	
	@GetMapping("/getFeedbackCount/{hostel}")
	public Integer getFeedbackCount(@PathVariable("hostel") String hostel) {
  		Log.debug("In the getFeedbackCount method");
		Integer num = feedbackproxy.getFeedbackCount(hostel);
		Log.debug("Returned value"+num);
		return num;
	}
	
	@GetMapping("/getFeedbackCountByRollnumber/{rollnumber}")
	public Integer getFeedbackCountByRollnumber(@PathVariable("rollnumber") long rollnumber) {
		Student student = this.studentproxy.getStudent(rollnumber);
		
		return this.feedbackproxy.getFeedbackCountByRollnumber(rollnumber);
	}
	
//	
//	
//	@PostMapping("/submitFeedback/{request_id}")
//	public Feedback submiFeedback(@RequestBody Feedback feedback,@PathVariable("request_id") int requestId) {
//		CleanRequest cleanRequestById = this.cleanRequestService.getCleanRequestById(requestId);
//			cleanRequestById.setFeedback_status(true);
//			CleanRequest submitRequest = this.cleanRequestService.submitRequest(cleanRequestById);
//		Student student = submitRequest.getStudent();
//		feedback.setCleanRequest(submitRequest);
//		feedback.setStudent(student);
//		return this.feedbackService.submitFeedback(feedback) ;
//	}
//	


//	

}
