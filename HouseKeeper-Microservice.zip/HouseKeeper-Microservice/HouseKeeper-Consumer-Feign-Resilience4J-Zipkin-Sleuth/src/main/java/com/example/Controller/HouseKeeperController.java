package com.example.Controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Entity.Worker;
import com.example.Proxy.HouseKeeperProxy;

@RestController
@CrossOrigin("*")
public class HouseKeeperController {

	@Autowired
	private HouseKeeperProxy housekeeperproxy;
	
	private static final Logger Log = LoggerFactory.getLogger(AdminController.class);


	@GetMapping("/getHouseKeeperByFloor/{floor}/{hostel}")
	public List<Worker> getWorkerByFloor(@PathVariable("floor") int floor,@PathVariable("hostel") String hostel){
		Log.debug("In the getWorkerByFloor method");
		List<Worker> worker=housekeeperproxy.getWorkerByFloor(floor,hostel);
		Log.debug("Returned value"+worker);
		return worker;

	}
	
	@GetMapping("/getHouseKeeperByHostel/{hostel}")
	public List<Worker> getWorkerByHostel(@PathVariable("hostel") String hostel){
		Log.debug("In the getWorkerByHostel method");
		List<Worker> worker=housekeeperproxy.getWorkerByHostel(hostel);
		Log.debug("Returned value"+worker);
		return worker;
	}
	
	@GetMapping("/getAllWorkers")
	public List<Worker> getAllWorkers(){
		Log.debug("In the getAllWorkers method");
		List<Worker> worker = housekeeperproxy.getAllWorkers();
		Log.debug("Returned value"+worker);
		return worker;
	}
	
	@GetMapping("getWorkers/{workerId}")
	public Worker getWorkerById(@PathVariable("workerId") int workerId) {
		Log.debug("In the getWorkerById method");
		Worker worker = housekeeperproxy.getWorkerById(workerId);
		Log.debug("Returned value"+worker);
		return worker;
	}

//	
//	@PostMapping("/registerWorker/{hostel}")
//	public Worker registerWorker(@RequestBody Worker worker,@PathVariable("hostel") String hostel) {
//		worker.setHostel(hostel);
//		return this.workerService.registerWorker(worker);	
//	}
//	

}
