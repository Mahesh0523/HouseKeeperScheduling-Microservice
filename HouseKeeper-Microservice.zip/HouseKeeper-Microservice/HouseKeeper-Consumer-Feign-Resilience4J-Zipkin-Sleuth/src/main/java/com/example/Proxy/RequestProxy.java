package com.example.Proxy;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.Entity.CleanRequest;
import com.example.Entity.Student;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;


@FeignClient(name="housekeeper-service")
public interface RequestProxy {

	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod = "fallbackgetRequestCount")
	@GetMapping("/requestCount/{rollno}")
	public List<Integer> getRequestCount(@PathVariable("rollno") long rollno);

	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod = "fallbackgetCleanRequestByRollnumber")
	@GetMapping("/getCleanRequestByRollnumber/{rollno}")
	public List<CleanRequest> getCleanRequestByRollnumber(@PathVariable("rollno") long rollno);

	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod = "fallbackgetCleanRequestById")
	@GetMapping("/getRequestById/{id}")
	public CleanRequest getCleanRequestById(@PathVariable("id") int id);
	
	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod = "fallbackgetAllCleanRequest")
	@GetMapping("/getAllCleanRequestByHostel/{hostel}")
	public List<CleanRequest> getAllCleanRequest(@PathVariable("hostel") String hostel);
	
	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod = "fallbackgetAllCleanRequestCount")
	@GetMapping("/getAllCleanRequestCountByHostel/{hostel}")
	public Integer getAllCleanRequestCount(@PathVariable("hostel") String hostel);
	
	
	public default List<Integer> fallbackgetRequestCount(long rollno, Throwable cause) {
		// TODO Auto-generated method stub
		System.out.println("Exception occured with message"+ cause.getMessage());

		return new ArrayList<Integer>();
	}

	
	public default List<CleanRequest> fallbackgetCleanRequestByRollnumber(long rollno, Throwable cause) {
		// TODO Auto-generated method stub
		System.out.println("Exception occured with message"+ cause.getMessage());

		return new ArrayList<CleanRequest>();
	}

	
	public default CleanRequest fallbackgetCleanRequestById(int id, Throwable cause) {
		// TODO Auto-generated method stub
		System.out.println("Exception occured with message"+ cause.getMessage());

		return null;
	}
	
	public default List<CleanRequest> fallbackgetAllCleanRequest(@PathVariable("hostel") String hostel, Throwable cause){
		System.out.println("Exception occured with message"+ cause.getMessage());

		return new ArrayList<CleanRequest>();
	}
	
	public default Integer fallbackgetAllCleanRequestCount(@PathVariable("hostel") String hostel, Throwable cause) {
		System.out.println("Exception occured with message"+ cause.getMessage());

		return 0;
	}
}
